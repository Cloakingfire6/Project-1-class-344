<?php
  echo 'If you're seeing this, then I am cooking up some lovely info for you!.<br />';
?>
