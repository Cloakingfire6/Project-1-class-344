<?php
  require('header.php');
?>
  <!-- page content -->
  <section>
     <h2>Welcome to Chef Ethan's services!</h2>
     <p>Please take some time to arrange your requests.</p>
     <p>Over here the 5 star meal comes right to your home.</p>
  </section>
<?php
  require('Ethanfooter.php');
?>

