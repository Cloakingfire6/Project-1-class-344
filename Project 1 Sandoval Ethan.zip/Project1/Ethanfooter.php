  <!-- page footer -->
  <footer>
      <p>&copy; Chef Ethan's personal chef service!.<br />
      Please see our menu for nutritional information
  </footer>

</body>
</html>

